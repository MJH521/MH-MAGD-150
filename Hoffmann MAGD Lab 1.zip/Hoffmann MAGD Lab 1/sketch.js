// Michael Hoffmann

function setup() {
  createCanvas(250, 250);
}

function draw() {

  // Background and Shape Outlines
  background(220);
  strokeWeight(12);
  strokeJoin(BEVEL);
  
  // Bottom White Rectangle (Ground)
  fill(255);
  rect(0, 225, 250, 20);
  
  // White Circle (Moon)
  fill(255);
  ellipse(40, 40, 50, 50);

  // Dark Gray Rectangle (Right Building)
  fill(80);
  rect(180, 220, 55, -120);
  
  // Light Gray Rectangle (Middle Building)
  fill(150);
  rect(80, 220, 70, -50);
  
  // No Color Fill Rectangle (Left Building)
  noFill();
  rect(20, 220, 30, -80);
  
}
