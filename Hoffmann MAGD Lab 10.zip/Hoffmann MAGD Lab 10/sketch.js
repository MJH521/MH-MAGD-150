// Michael Hoffmann

// Snowflake Portrait
function setup() {
  createCanvas(500, 500);
  colorMode(RGB);
}

function draw() {
  background(0);
  noStroke();
  translate(250,250);

// p5.Polar Function Shapes
  fill(22, 238, 249);
  polarEllipses(6, 50, 50, 170);
  fill(22, 238, 249);
  polarHexagons(6, 58, 100);
  fill(22, 124, 249);
  polarHexagons(6, 29, 100);
  fill(0);
  polarHexagons(6, 15, 100);
  fill(22, 124, 249);
  polarTriangles(6, 34, 167);
  fill(0);
  polarTriangles(6, 17, 167);
  
// Border Triangles
  fill(22, 124, 249);

  // Bottom Right
  push();
  translate(150, 150);
  triangle(100, 0, 100, 100, 0, 100);
  pop();
  
  // Bottom Left
  push();
  translate(-150, 150);
  rotate(HALF_PI);
  triangle(100, 0, 100, 100, 0, 100);
  pop();
  
  // Top Right
  push();
  translate(150, -150);
  rotate(-HALF_PI);
  triangle(100, 0, 100, 100, 0, 100);
  pop();
  
  // Top Left
  push();
  translate(-150, -150);
  rotate(PI);
  triangle(100, 0, 100, 100, 0, 100);
  pop();
}